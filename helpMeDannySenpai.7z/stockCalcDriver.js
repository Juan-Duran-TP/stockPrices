const getMaxProfit = require('./stockCalc.js')
const getPrices = require('./stockCalc.js')
let min = "1min";

let = priceArray = [];
priceArray = getPrices()
const p = getMaxProfit(priceArray)
    console.log(priceArray)
// getPrices().then(data => {
//     let item;
//     for (const timestamp in data[`Time Series (${min})`]) {
//       item = data[`Time Series (${min})`][timestamp]["4. close"];
//       priceArray.push(parseFloat(item));
//     }
//     const p = getMaxProfit(priceArray)
//     console.log(p)
// });
