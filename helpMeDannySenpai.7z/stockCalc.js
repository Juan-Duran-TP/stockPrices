/* How much money could you have made yesterday if you spent all day
trading Google stocks (GOOG; ABC)?

1. Get historic stock prices from yesterday, store
them in a list
2. this list may be an array with minutes after
opening bell (9:30AM) as indices. Values are price (in USD) of one 
share of the stock at the time.

Example: if stock was $500 at 10:30 AM,
'stockPrice[60] = 500'.


Write an efficient function that takes the stock price data
and returs the best profit you could make from one purchase and
one sale of one share yesterday.

You may not short (sell before you buy). You cannot buy and sell in the same minute; at least
one minute should pass between buying and selling. 

//
stockPrices = [ 10, 7, 5, 8, 11, 9];
getMaxProfit(stockPrices) // 6 (buy for $5, sell for $11)
*/

const fetch = require("node-fetch");
let min = "1min";


function getMaxProfit(stockPrices) {
    if (!stockPrices || stockPrices.length < 2){
        console.error('Invalid input, requires an array of at least 2 numeric stock prices');
        return Error('Invalid input, requires an array of at least 2 numeric stock prices');
    }
    let maxProfit = 0;
    let minBuy = stockPrices[0] ;
    let profit = 0;
    let minLoss = Number.NEGATIVE_INFINITY;
    let prev = stockPrices[0];
    let loss = 0;
    for (let i = 1; i < stockPrices.length; i++){
        profit = stockPrices[i] - minBuy;
        prev = stockPrices[i];
        if (profit > minLoss){
            minLoss = profit;
        }
        if (profit > maxProfit){
            maxProfit = profit;
        }
        if (stockPrices[i] < minBuy ){
            minBuy = stockPrices[i];
        }
    }
    if (maxProfit === 0){ // negative trend
        maxProfit = minLoss;
    }
    return maxProfit;
}

async function getPrices() {
    let addresses;
    try {
      const response = await fetch(
        `https://www.alphavantage.co/query?function=TIME_SERIES_INTRADAY&symbol=GOOG&outputsize=full&interval=${min}&apikey=266O79C8AOTKG4R2`
      );
      addresses = await response.text();
      addresses = JSON.parse(addresses);
      console.log(addresses)
      return addresses;
    } catch (error) {
      console.error("Error:", error);
      return null;
    }
}


module.exports = getMaxProfit;
module.exports = getPrices;